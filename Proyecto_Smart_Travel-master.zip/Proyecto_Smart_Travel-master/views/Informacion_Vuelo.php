<?php

class Informacion_Vuelo extends View{

  public $datos_vuelo;

}

?>
