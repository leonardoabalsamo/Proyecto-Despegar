<?php

class AgregarEmpresa extends View{

  public $resultado;

}


?>
