<?php 

class Favoritos extends View{

	public $favoritos;
	public $mensaje;
	
}

 ?>