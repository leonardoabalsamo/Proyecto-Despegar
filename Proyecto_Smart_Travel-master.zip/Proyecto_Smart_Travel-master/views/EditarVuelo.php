<?php

class EditarVuelo extends View{

    public $vuelos;
    public $datos_vuelo;
    public $resultado;
}

?>
