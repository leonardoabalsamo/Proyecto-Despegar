<?php

class AgregarVuelo extends View{

  public $id_empresa;
  public $resultado;
  public $vuelos;

}


?>
