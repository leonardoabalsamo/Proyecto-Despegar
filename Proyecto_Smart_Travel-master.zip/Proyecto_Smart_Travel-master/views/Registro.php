<?php

class Registro extends View{

	public $error;
	public $id_vuelo;
	public $redireccion;
	public $mensaje;

}

 ?>
