<?php

class Mis_Reclamos extends View{

  public $reclamos;
  public $mensaje;
  public $resultado;

}


?>
