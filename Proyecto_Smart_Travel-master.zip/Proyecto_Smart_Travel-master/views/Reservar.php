<?php

class Reservar extends View{

  public $id_vuelo;
  public $datos_vuelo;
  public $dni;
  public $cant_restante;

}



?>
