<?php

class Reclamos_Admin extends View{

  public $reclamos;
  public $mensaje;
  public $resultado;

}


?>
