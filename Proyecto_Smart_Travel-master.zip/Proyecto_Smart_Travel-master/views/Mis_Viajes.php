<?php

class Mis_Viajes extends View{

  public $reservas;
  public $mensaje;
  public $resultado;

}


?>
