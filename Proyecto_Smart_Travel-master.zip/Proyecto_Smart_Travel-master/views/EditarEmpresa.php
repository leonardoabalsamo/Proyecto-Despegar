<?php

class EditarEmpresa extends View{

    public $datos_empresa;
    public $resultado;
}

?>
