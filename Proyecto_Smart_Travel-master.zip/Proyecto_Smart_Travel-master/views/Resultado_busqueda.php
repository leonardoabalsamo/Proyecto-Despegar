<?php

class Resultado_busqueda extends View{

    public $resultado;

}
