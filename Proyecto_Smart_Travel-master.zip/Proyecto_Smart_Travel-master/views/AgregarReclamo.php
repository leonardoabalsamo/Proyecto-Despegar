<?php

class AgregarReclamo extends View{

  public $id_reserva;

}


?>
