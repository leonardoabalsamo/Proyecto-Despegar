<?php

class Ayuda extends View{

  public $empresas;

}

?>
