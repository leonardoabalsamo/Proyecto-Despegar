<?php

class Administrador extends View{

  public $empresas;
  public $vuelos_empresa;
  public $resultado;
  public $id_empresa;
  public $nombre_empresa;

}

?>
