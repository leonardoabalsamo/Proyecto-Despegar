<?php

class Principal extends View{

    public $vuelos_precio_minimo;
    public $favoritos;
    public $mensaje;

}
