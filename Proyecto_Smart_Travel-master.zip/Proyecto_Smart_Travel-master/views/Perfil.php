<?php

class Perfil extends View{

	public $id_login;
	public $mail;
	public $nombre;
	public $apellido;
	public $dni;
	public $direccion;
	public $telefono;
	public $error;
	public $id_vuelo;

	public $mensaje;
	public $redireccion;

}

?>
