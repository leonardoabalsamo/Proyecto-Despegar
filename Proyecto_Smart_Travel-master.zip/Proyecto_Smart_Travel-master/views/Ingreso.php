<?php

class Ingreso extends View{

	public $estado;
	public $resultado;
	public $error;
	public $mensaje;
	public $redireccion;

}
