<div class="header">

    <a href="../controllers/principal.php">
      <img src="../media/fondo.jpg" style="max-width: 100%">
    </a>

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <div class="container-fluid"  >
        <div class="row w-100">
          <div class="col-10"></div>
          <div class="col-2 text-end">
            <button type="button" class="btn btn-outline-info m-0 p-1 px-4" name="button">
              <a class="navbar-brand m-0 p-0" style="font-size: 18px;" href="../controllers/ayuda.php">Centro de Ayuda</a>
            </button>
          </div>
        </div>
      </div>
    </nav>

</div>
