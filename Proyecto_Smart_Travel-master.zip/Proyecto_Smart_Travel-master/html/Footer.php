<div class="modal-footer">
    <p style="font-style:italic;color:black">Cualquier consulta no dude en contactarnos al:</p>
    <p style="color:black">contacto@smarttravel.com</p>
    <p style="color:black">(+54)-9-11-22334455</p>
</div>
