<?php

// fw/fw.php

require '../fw/Database.php';
require '../fw/Model.php';
require '../fw/View.php';